"""
Lunar Lander - ML Agent (Phase 3)
Machine Learning I - UC3M 2025-2026

Modified game loop that loads the trained DecisionTreeClassifier
and uses it to control the lander at each timestep.
"""

import gymnasium as gym
import time
import math
import pygame
import joblib
import numpy as np

# ──────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────

GRAVITY = -1.62
ENV_NAME = "LunarLander-v3"
MODEL_PATH = "lunarlander_tree_raw.pkl"     # produced by train_classifier.py

# Number of episodes to run for performance evaluation
NUM_EPISODES = 10

# Action definitions
ACTION_NOTHING     = 0
ACTION_LEFT_ENGINE = 1
ACTION_MAIN_ENGINE = 2
ACTION_RIGHT_ENGINE = 3


# ──────────────────────────────────────────────
# GAME STATE CLASS  (same as LunarLander_raw.py)
# ──────────────────────────────────────────────

class GameState:
    def __init__(self, observation):
        self.x_position      = observation[0]
        self.y_position      = observation[1]
        self.x_velocity      = observation[2]
        self.y_velocity      = observation[3]
        self.angle           = observation[4]
        self.angular_velocity= observation[5]
        self.left_leg_contact= observation[6]
        self.right_leg_contact=observation[7]
        self.observation     = observation
        self.score           = 0.0
        self.episode_reward  = 0.0
        self.action          = ACTION_NOTHING

    def update(self, observation, reward):
        self.x_position      = observation[0]
        self.y_position      = observation[1]
        self.x_velocity      = observation[2]
        self.y_velocity      = observation[3]
        self.angle           = observation[4]
        self.angular_velocity= observation[5]
        self.left_leg_contact= observation[6]
        self.right_leg_contact=observation[7]
        self.observation     = observation
        self.episode_reward += reward
        self.score           = self.episode_reward

    def reset(self, observation):
        self.__init__(observation)


# ──────────────────────────────────────────────
# ML AGENT  —  converts state to feature vector
#              and calls model.predict()
# ──────────────────────────────────────────────

def move_ml_agent(game, model):
    """
    Build the raw feature vector from the current game state,
    then ask the trained classifier for the best action.

    Feature order must exactly match the columns used during training:
        x_position, y_position, x_velocity, y_velocity,
        angle, angular_velocity, left_leg_contact, right_leg_contact
    """
    features = np.array([[
        game.x_position,
        game.y_position,
        game.x_velocity,
        game.y_velocity,
        game.angle,
        game.angular_velocity,
        game.left_leg_contact,
        game.right_leg_contact,
    ]])

    action = model.predict(features)[0]
    return int(action)


# ──────────────────────────────────────────────
# PRINT STATE  (terminal debug)
# ──────────────────────────────────────────────

def print_state(game):
    print("--------GAME STATE--------")
    print(f"Position: X={game.x_position:.3f}, Y={game.y_position:.3f}")
    print(f"Velocity: X={game.x_velocity:.3f}, Y={game.y_velocity:.3f}")
    print(f"Angle: {game.angle:.3f} rad  Angular vel: {game.angular_velocity:.3f}")
    print(f"Legs: L={game.left_leg_contact:.0f}  R={game.right_leg_contact:.0f}")
    print(f"Score: {game.score:.2f}  Action: {game.action}")
    print("--------------------------")


# ──────────────────────────────────────────────
# MAIN GAME LOOP
# ──────────────────────────────────────────────

def main():
    print("=" * 50)
    print("LUNAR LANDER - ML Agent (Phase 3)")
    print("UC3M - Machine Learning I")
    print("=" * 50)

    # ── Load trained model ──
    print(f"\nLoading model from: {MODEL_PATH}")
    model = joblib.load(MODEL_PATH)
    print("Model loaded successfully.")
    print(f"  Type: {type(model).__name__}")
    print(f"  Tree depth: {model.get_depth()} | Leaves: {model.get_n_leaves()}")

    pygame.init()

    env = gym.make(ENV_NAME, gravity=GRAVITY, render_mode="human")
    print(f"\nEnvironment: {ENV_NAME}  |  Gravity: {GRAVITY}")
    print(f"Running {NUM_EPISODES} episodes with ML agent...\n")
    print("Press Q or ESC to quit early.")
    print("-" * 50)

    # ── Statistics tracking ──
    episode_rewards = []
    successful_landings = 0

    observation, info = env.reset()
    game = GameState(observation)

    clock = pygame.time.Clock()
    episode_count = 0
    running = True

    try:
        while running and episode_count < NUM_EPISODES:

            # Handle pygame events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_ESCAPE, pygame.K_q):
                        running = False

            if not running:
                break

            # ── ML agent picks the action ──
            action = move_ml_agent(game, model)
            game.action = action

            # ── Step environment ──
            observation, reward, terminated, truncated, info = env.step(action)
            game.update(observation, reward)

            print_state(game)

            # ── Episode end ──
            if terminated or truncated:
                episode_count += 1
                episode_rewards.append(game.score)

                landed = (game.left_leg_contact and game.right_leg_contact
                          and game.score > 0)

                if terminated:
                    if landed:
                        successful_landings += 1
                        print(f"\n*** EPISODE {episode_count}: SUCCESSFUL LANDING! "
                              f"Score={game.score:.2f} ***\n")
                    elif game.score > 0:
                        print(f"\n*** EPISODE {episode_count}: Landed (partial). "
                              f"Score={game.score:.2f} ***\n")
                    else:
                        print(f"\n*** EPISODE {episode_count}: CRASH. "
                              f"Score={game.score:.2f} ***\n")
                else:
                    print(f"\n*** EPISODE {episode_count}: Truncated. "
                          f"Score={game.score:.2f} ***\n")

                time.sleep(1)
                observation, info = env.reset()
                game.reset(observation)

            clock.tick(30)

    except KeyboardInterrupt:
        print("\nInterrupted by user.")
    finally:
        env.close()
        pygame.quit()

    # ── Final performance report ──
    if episode_rewards:
        print("\n" + "=" * 50)
        print("ML AGENT PERFORMANCE SUMMARY")
        print("=" * 50)
        print(f"Episodes completed : {episode_count}")
        print(f"Avg total reward   : {sum(episode_rewards)/len(episode_rewards):.2f}")
        print(f"Max reward         : {max(episode_rewards):.2f}")
        print(f"Min reward         : {min(episode_rewards):.2f}")
        print(f"Successful landings: {successful_landings}/{episode_count} "
              f"({100*successful_landings/episode_count:.1f}%)")
        print("=" * 50)


if __name__ == "__main__":
    main()
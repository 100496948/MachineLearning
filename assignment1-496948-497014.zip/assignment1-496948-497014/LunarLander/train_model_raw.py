"""
Train a DecisionTreeClassifier using RAW features only.
Machine Learning I - UC3M
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import joblib

# ── 1) Load CSV (raw features) ──
DATA_PATH = "data_agent_raw.csv"  # change to your raw dataset path
df = pd.read_csv(DATA_PATH)

print("Class distribution:")
print(df["action"].value_counts().sort_index())
print(f"\n% clase mayoritaria: {df['action'].value_counts().max() / len(df) * 100:.1f}%")

# ── 2) Separate inputs (X) and label (y) ──
# Drop 'action' (target) and 'next_reward' (future info, not available at deployment)
y = df["action"]
X = df.drop(columns=["action", "next_reward"])

print(f"Dataset: {DATA_PATH}")
print(f"Total instances: {len(df)}")
print(f"Features ({X.shape[1]}): {list(X.columns)}")
print(f"Class distribution:\n{y.value_counts().sort_index()}\n")

# ── 3) Train/test split ──
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"Train size: {len(X_train)}, Test size: {len(X_test)}\n")

# ── 4) Train model ──
clf = DecisionTreeClassifier(random_state=42)  # optional: max_depth=10
clf.fit(X_train, y_train)

# ── 5) Evaluate ──
y_pred = clf.predict(X_test)

print("=" * 50)
print("RESULTS - RAW FEATURES")
print("=" * 50)
print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print(f"\nConfusion Matrix:\n{confusion_matrix(y_test, y_pred)}")
print(f"\nClassification Report:\n{classification_report(y_test, y_pred)}")

# ── 6) Save model ──
MODEL_PATH = "lunarlander_tree_raw.pkl"
joblib.dump(clf, MODEL_PATH)
print(f"Saved model to {MODEL_PATH}")